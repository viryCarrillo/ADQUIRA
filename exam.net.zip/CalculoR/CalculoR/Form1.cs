﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using operacion;

namespace CalculoR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e){

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            calculo opr = new calculo();
            int a = Convert.ToInt32(textBox1.Text);
            //int p =Convert.ToInt32(ToString());
            //int suma = Convert.ToInt32(ToString());
            //int div = Convert.ToInt32(ToString());
            String result = textBox2.Text + " " + opr.mayor(a);
            textBox2.Text = result;
            String resul = textBox3.Text + " " + opr.mayor(a) * 4; 
            textBox3.Text = resul;
            String res = textBox4.Text + " " + opr.mayor(a) + 67;
            textBox4.Text = res;
           // String r = textBox5.Text + " " + opr.mayor(a) - 78;
            //textBox4.Text = r;
            String t = textBox6.Text + " " + opr.mayor(a) / 7;
            textBox4.Text = t;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }
    }
}
