﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operacion
{
    public class calculo
    {
        public int mayor(int a)
        {
            return a % 1000000;
        }
        public int mutl(int p, int a, int b, int c, int d, int g, int f, int res1, int res2, int res3, int res4, int res5, int res6)
        {
            res1 = a % 10;
            res2 = res1 / 10;
            b = res2 % 10;
            res3 = b / 10;
            c = res3 % 10;
            res4 = c / 10;
            d = res4 % 10;
            res5 = d / 10;
            g = res5 % 10;
            res6 = g / 10;
            f = res6 % 10;

            return p = (res1 * 2) & (b * 3) & (c * 4) & (d * 5) & (g * 6) & (f * 7);
        }
        public int suma(int p, int a, int b, int c, int d, int g, int f, int res1, int res2, int res3, int res4, int res5, int res6)
        {
            res1 = a % 10;
            res2 = res1 / 10;
            b = res2 % 10;
            res3 = b / 10;
            c = res3 % 10;
            res4 = c / 10;
            d = res4 % 10;
            res5 = d / 10;
            g = res5 % 10;
            res6 = g / 10;
            f = res6 % 10;

            return p = (res1 + 2) & (b + 3) & (c + 4) & (d + 5) & (g + 6) & (f + 7);
        }
        public int div(int suma)
        {
            return suma / 7;
        }
        public int res(int div)
        {
            return div - 7;
        }
    }
}
